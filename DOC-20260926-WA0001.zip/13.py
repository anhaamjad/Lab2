sample_data = "0100,0011,1010,1001,1100,1001"
bin = sample_data.split(",")
divisible_by_5 = [b for b in bin if int(b,2) % 5 == 0]
print(",".join(divisible_by_5))
