def read_lines_lowercase():
 l=[]
 while True:
  line = input()
  if line == "":
   break                    
  l.append(line.lower())
 for line in l:
  print(line)