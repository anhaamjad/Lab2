def reverse_word(word):
    return word[::-1]
word = "python" 
print(reverse_word(word))