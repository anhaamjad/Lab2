def count_dl(s):
 digits = sum(1 for ch in s if ch.isdigit())
 letters = sum(1 for ch in s if ch.isalpha())
 return letters, digits

sample_str = "Python 3.2"
letters, digits = count_dl(sample_str)
print(f"Letters {letters}")
print(f"Digits {digits}")
