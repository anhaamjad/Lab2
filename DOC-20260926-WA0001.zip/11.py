def build__2d__arr(m, n):
 return [[i * j for j in range(n)] for i in range(m)]
rows, cols = 3, 4
print(build__2d__arr(rows, cols))