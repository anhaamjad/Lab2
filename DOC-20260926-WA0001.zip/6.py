numbers = (1, 2, 3, 4, 5, 6, 7, 8, 9)
ecount = sum(1 for x in numbers if x % 2 == 0)
ocount = len(numbers) - ecount
print(f" even : {ecount}")
print(f" odd : {ocount}")