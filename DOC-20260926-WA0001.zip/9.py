a, b = 0, 1
fib = []
while a <= 50:
 fib.append(a)
 a, b = b, a + b
print(" ".join(str(x) for x in fib))