import re
def is_valid_password(password):
 if not (6 <= len(password) <= 16):
  return False
 if not re.search(r'[a-z]', password):
  return False
 if not re.search(r'[A-Z]', password):
  return False
 if not re.search(r'[0-9]', password):
  return False
 if not re.search(r'[$#@]', password):
  return False
 return True

test_passwords = ["Passw0rd$", "weak", "NoDigits$", "ALLCAPS123$", "goodPass1@"]
for pw in test_passwords:
 print(f"{pw}: {'Valid' if is_valid_password(pw) else 'Invalid'}")
