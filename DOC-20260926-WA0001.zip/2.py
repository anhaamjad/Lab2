def celsius_to_fahrenheit(c):
    return (c * 9 / 5) + 32
def fahrenheit_to_celsius(f):
    return (f - 32) * 5 / 9

c = 60
f = 45
print(f"{c}°C is {celsius_to_fahrenheit(c):.0f} in Fahrenheit")
print(f"{f}°F is {fahrenheit_to_celsius(f):.0f} in Celsius")
            